package com.mavericks.games.service;

import java.util.Map;

public interface IRPSService {
    public Map<String, String> playGame(String gameMode, String move);
}
