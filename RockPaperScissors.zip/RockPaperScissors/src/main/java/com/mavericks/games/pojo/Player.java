package com.mavericks.games.pojo;

public class Player extends RPSPlayer {
    // add player specific properties
}