package com.mavericks.games.pojo;

import com.mavericks.games.enums.Move;
import lombok.Data;

@Data // lombok @Data annotation for setter's and getter's toString() equals() and hashCode()
// base class for defining common properties for all types of players
public class RPSPlayer {
    private String name;
    private Double socre;

}