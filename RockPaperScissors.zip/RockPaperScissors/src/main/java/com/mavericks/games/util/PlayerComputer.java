package com.mavericks.games.util;

import com.mavericks.games.enums.Move;
import com.mavericks.games.pojo.Computer;
import com.mavericks.games.pojo.Player;

import java.util.HashMap;
import java.util.Map;

public class PlayerComputer implements PlayerCombinations {
    private Player player;
    private Computer computer;

    public PlayerComputer() {
        player = new Player();
        computer = new Computer();
        player.setName("YOU");
        computer.setName("Computer");
    }

    @Override
    public Map<String, String> play(String selectedMove) {
        Map<String, String> response = new HashMap<>();
        // Get Player move
        Move playerMove = Move.valueOf(selectedMove);
        // Get Random Computer move
        Move computerMove = RPSHelper.getMove();
        // Comparing move's and deciding winner.
        String winner = RPSHelper.decideWinner(playerMove.compareMoves(computerMove), player.getName());

        // Adding results to map.
        response.put("player", playerMove.toString());
        response.put("computer", computerMove.toString());
        response.put("name", "You");
        response.put("result", winner);
        return response;
    }
}