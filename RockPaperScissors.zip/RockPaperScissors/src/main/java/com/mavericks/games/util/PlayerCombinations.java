package com.mavericks.games.util;

import java.util.Map;

public interface PlayerCombinations {
    public Map<String, String> play(String selectedMove);
}
