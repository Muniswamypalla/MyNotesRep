package com.mavericks.games.pojo;

public class Computer extends RPSPlayer {
    // add computer specific properties
}