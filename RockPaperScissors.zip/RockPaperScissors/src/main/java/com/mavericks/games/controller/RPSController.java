package com.mavericks.games.controller;

import com.jayway.jsonpath.JsonPath;
import com.mavericks.games.service.RPSService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class RPSController {

    @Autowired
    private RPSService rpsService;

    @PostMapping(path="/rps",consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {
            MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<String> playGame(@RequestBody String reqJson) {
        // Reading game mode and move from request.
        String gameMode = JsonPath.parse(reqJson).read("$.gameMode");
        String move = JsonPath.parse(reqJson).read("$.move");

        // Calling service class to get result.
        Map<String, String> jsonMap = rpsService.playGame(gameMode, move);

        // Returning json to UI.
        return ResponseEntity.ok().body(JsonPath.parse(jsonMap).jsonString());
    }

}
