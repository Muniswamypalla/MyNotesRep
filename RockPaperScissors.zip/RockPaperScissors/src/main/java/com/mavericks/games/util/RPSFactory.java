package com.mavericks.games.util;

import org.springframework.stereotype.Component;

public class RPSFactory {
    private enum PlayMode {
        PC, CC;
    }

    // Factory method for returning different playing mode object's
    public static PlayerCombinations getPlayingMode(String playMode) {
        switch (PlayMode.valueOf(playMode)) {
            case PC:
                return new PlayerComputer();
            case CC:
                return new ComputerComputer();
            default:
                throw new IllegalArgumentException();
        }

    }
}
