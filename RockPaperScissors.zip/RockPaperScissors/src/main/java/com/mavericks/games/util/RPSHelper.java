package com.mavericks.games.util;

import com.mavericks.games.enums.Move;

import java.util.Random;

public class RPSHelper {

   public static Move getMove() {
        Move[] moves = Move.values();
        Random random = new Random();
        int index = random.nextInt(moves.length);
        return moves[index];
    }

    public static String decideWinner(int compareMoves, String name) {
        switch (compareMoves) {
            case 0: // Tie
                return "Tie!";
            case 1: // Player wins
                return name + " won!";
            case -1: // Computer wins
                return name + " lost!";
            default:
                throw new IllegalArgumentException();
        }
    }

}
