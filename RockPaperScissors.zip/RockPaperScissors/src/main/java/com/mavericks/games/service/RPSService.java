package com.mavericks.games.service;

import com.mavericks.games.util.PlayerCombinations;
import com.mavericks.games.util.RPSFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@Service
public class RPSService implements IRPSService{

    public Map<String, String> playGame(String gameMode, String move) {
        // Calling Factory getPlayingMode() to get different playing mode objects.
        // We can also use Facade pattern in case if system become's more complex.
        PlayerCombinations playingMode = RPSFactory.getPlayingMode(gameMode);
        return playingMode.play(move);
    }
}
