package com.mavericks.games.util;

import com.mavericks.games.enums.Move;
import com.mavericks.games.pojo.Computer;
import com.mavericks.games.util.PlayerCombinations;

import java.util.HashMap;
import java.util.Map;

public class ComputerComputer implements PlayerCombinations {
    private Computer computer1;
    private Computer computer2;

    public ComputerComputer() {
        computer1 = new Computer();
        computer2 = new Computer();
        computer1.setName("Computer1");
        computer2.setName("Computer2");
    }

    @Override
    public Map<String, String> play(String selectedMove) {
        Map<String, String> response = new HashMap<>();
        // Get Random Computer move
        Move computer1Move = RPSHelper.getMove();
        // Get Random Computer move
        Move computer2Move = RPSHelper.getMove();
        // Comparing move's and deciding winner.
        String winner = RPSHelper.decideWinner(computer1Move.compareMoves(computer2Move), computer1.getName());

        // Adding results to map.
        response.put("computer1", computer1Move.toString());
        response.put("computer2", computer2Move.toString());
        response.put("name", "computer1");
        response.put("result", winner);
        return response;
    }
}