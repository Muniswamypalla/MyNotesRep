var  screen = document.getElementById("screen"), playerChoice = "", pcChoice = "", mode = "", resjson = {};

$(document).ready(()=>{
  showInitScreen();
});

function showInitScreen(){
  mode = "";
  f = '<div class="row"><div class="column"><img align="left" src="images/background.jpg" style="width:400px;height:400px;" alt="Rock"></div>'
  +'<div class="column"><br><br><br><br><br><br><br><br><button align="right" type="button" id="PvsC" onclick="startGame(this);" value="PC">Player vs Computer</button><br><br>'
  +'<button type="button" id="CvsC" onclick="changeMode(\'CC\');play(\'\');" value="CC" >Computer vs Computer</button></div></div>';
  fillScreen(f);
}

function play(option){
  pcChoice = "";
  playerChoice = "";
  fire_ajax_submit(mode, option);
}

function changeMode(mode){
    this.mode = mode;
}

function fire_ajax_submit(mode, option) {
    var search = { gameMode: mode, move: option};

    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/rps",
        data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            resjson = JSON.stringify(data, null, 4);
            console.log("SUCCESS : ", resjson);
            showChoises(JSON.parse(resjson));
        },
        error: function (e) {
            resjson = e.responseText;
            console.log("ERROR : ", resjson);
        }
    });
}

function homescreen() {
    $.ajax({
        type: "GET",
        url: "",
        cache: false,
        timeout: 600000,
        success: function (data) {
            showInitScreen();
        },
        error: function (e) {
            showInitScreen();
        }
    });
}

function startGame(buttonobj){
debugger;
  f = '';
  if("PA"!=buttonobj.value){
    mode = buttonobj.value;
  }
  if("PA"==buttonobj.value && "CC"==mode){
    fire_ajax_submit(mode, "")
  }else{
    fillScreen(f);
    showGameBoard();
  }
}

function fillScreen(fill){
  screen.innerHTML = "";
  screen.innerHTML = fill;
}

function showGameBoard(){
var playingMode;
  var board = '<br><h2>Player vs Computer</h2>'+'<div class="p-move"><br><h2>Select Your Move</h2><div class="p-move"><div class="p-move-option"><a href="javascript:play(\'ROCK\');"><img src="images/rock.png" style="width:100px;height:100px;" alt="Rock"></a></div><div class="p-move-option"><a href="javascript:play(\'PAPER\');"><img src="images/paper.png" style="width:100px;height:100px;" alt="Paper" ></a></div><div class="p-move-option"><a href="javascript:play(\'SCISSORS\');"><img src="images/scissors.png" style="width:100px;height:100px;" alt="Scissors"></a></div></div>';
  screen.innerHTML += board;
}

function showChoises(resjson){
var pcTag = '';
var playerTag = '';
   if(mode == 'PC'){
   playerChoice = resjson.player;
   pcChoice = resjson.computer;
   }else{
      playerChoice = resjson.computer1;
      pcChoice = resjson.computer2;
   }

   switch(playerChoice){
       case "ROCK":
         playerTag = '<h2>'+resjson.name+' Choosen</h2><br><img alt="Rock" src="images/rock.png" style="width:100px;height:100px;" />';
         break;
       case "PAPER":
         playerTag = '<h2>'+resjson.name+' Choosen</h2><br><img alt="Paper" src="images/paper.png" style="width:100px;height:100px;"/>';
         break;
       case "SCISSORS":
         playerTag = '<h2>'+resjson.name+' Choosen</h2><br><img alt="Scissors" src="images/scissors.png" style="width:100px;height:100px;"/>';
         break;
   }
  switch(pcChoice){
    case "ROCK":
      pcTag = '<img src="images/rock.png" alt="Rock" style="width:100px;height:100px;"/>';
      break;
    case "PAPER":
      pcTag = '<img src="images/paper.png" alt="Paper" style="width:100px;height:100px;"/>';
      break;
    case "SCISSORS":
      pcTag = '<img src="images/scissors.png" alt="Scissors" style="width:100px;height:100px;"/>';
      break;
  }

  var choices = '<div class="moves-board"><div class="choise" id="pc-choise"><div style="height: 10px;"></div>';
  choices += pcTag;
  choices += '</div>'

	choices += '<br><h2>'+resjson.result+'</h2>';
	choices += '<button type="button" id="startGameBtn" onclick="startGame(this);" value="PA">Play Again</button>';
	choices += '&nbsp&nbsp&nbsp<button type="button" id="startGameBtn" onclick="homescreen();">Change Mode</button>';
  
  choices += '<br><br><div class="choise" id="player-choise">';
  choices += playerTag;
  choices += '</div></div>';

  fillScreen("");
  fillScreen(choices);
}
