package com.mavericks.games;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@RunWith(SpringRunner.class)
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = RockPaperScissorsApplication.class
)
@AutoConfigureMockMvc
public class RockPaperScissorsApplicationTests {

    @Autowired
    MockMvc mockMvc;

    @Test
    public void playerVScomputerTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/api/rps/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"gameMode\":\"PC\",\"move\":\"ROCK\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.player", Matchers.is("ROCK")))
                .andExpect(MockMvcResultMatchers.jsonPath("$.result", Matchers.notNullValue()));
    }

    @Test
    public void computerVScomputerTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/api/rps/")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"gameMode\":\"CC\",\"move\":\"\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.result", Matchers.notNullValue()));
    }

}
