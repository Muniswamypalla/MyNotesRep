package com.arya.intprog;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {

        assertTrue( false );
    }

    @Test
    public void shouldAnswerWithTrue1()
    {

        assertTrue( true );
    }

    @Test
    public void shouldAnswerWithTrue2()
    {

        assertTrue( false );
    }
}
