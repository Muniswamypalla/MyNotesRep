package com.arya.intprog.java8;

public class Missing {
    public static void main(String[] args) {

    }
}
